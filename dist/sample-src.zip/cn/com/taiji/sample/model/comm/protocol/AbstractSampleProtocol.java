/*
 * Date: 2016年3月24日
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.sample.model.comm.protocol;

import cn.com.taiji.common.model.file.AbstractBinProtocol;

/**
 * 
 * @author Peream <br>
 *         Create Time：2016年3月24日 下午2:39:45<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class AbstractSampleProtocol extends AbstractBinProtocol
{
	protected static String extractSuffix(String filename)
	{
		int index = filename.lastIndexOf('.');
		return filename.substring(index + 1).toLowerCase();
	}
}
