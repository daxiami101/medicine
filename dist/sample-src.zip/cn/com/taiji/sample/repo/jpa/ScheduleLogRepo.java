package cn.com.taiji.sample.repo.jpa;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.ScheduleLog;

public interface ScheduleLogRepo extends AbstractJpaRepo<ScheduleLog, String>
{
	
}
