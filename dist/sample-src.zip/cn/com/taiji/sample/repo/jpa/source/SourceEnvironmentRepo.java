package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourceEnvironment;

public interface SourceEnvironmentRepo extends AbstractJpaRepo<SourceEnvironment, String>
{
}
