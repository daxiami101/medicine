package cn.com.taiji.sample.repo.jpa.source;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.land.SourceSeedHandle;

public interface SourceSeedHandleRepo extends AbstractJpaRepo<SourceSeedHandle, String>
{
	@Query(" from SourceSeedHandle where 1=1 and taskId=?1")
	public List<SourceSeedHandle> listByTaskId(String taskId);
}
