package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourceTransport;

public interface SourceTransportRepo extends AbstractJpaRepo<SourceTransport, String>
{
}
