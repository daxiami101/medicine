package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourcePlantTask;

public interface SourcePlantTaskRepo extends AbstractJpaRepo<SourcePlantTask, String>
{
}
