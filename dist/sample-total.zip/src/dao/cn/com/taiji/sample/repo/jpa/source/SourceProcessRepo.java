package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourceProcess;

public interface SourceProcessRepo extends AbstractJpaRepo<SourceProcess, String>
{
}
