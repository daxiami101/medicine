package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourceProduction;

public interface SourceProductionRepo extends AbstractJpaRepo<SourceProduction, String>
{
}
