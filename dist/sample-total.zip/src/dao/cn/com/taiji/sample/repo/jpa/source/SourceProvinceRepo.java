package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourceProvince;

public interface SourceProvinceRepo extends AbstractJpaRepo<SourceProvince, String>
{
}
