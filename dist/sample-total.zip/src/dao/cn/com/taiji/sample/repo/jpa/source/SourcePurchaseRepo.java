package cn.com.taiji.sample.repo.jpa.source;

import cn.com.taiji.common.repo.jpa.AbstractJpaRepo;
import cn.com.taiji.sample.entity.source.SourcePurchase;

public interface SourcePurchaseRepo extends AbstractJpaRepo<SourcePurchase, String>
{
}
