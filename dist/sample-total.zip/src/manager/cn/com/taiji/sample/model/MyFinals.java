package cn.com.taiji.sample.model;

import cn.com.taiji.common.model.finals.SysFinals;

/**
 * 
 * @author Peream <br>
 *         Create Time：2010-9-10 下午04:13:09<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public class MyFinals extends SysFinals
{
	public static String COOKIE_USER = "mycookieuser";
	public static String COOKIE_PASS = "mycookiepass";

	public final static String CRON_TASK_TABLE = "SAMPLE_CRON_EXCLUSIVE_TASK";
	
}
