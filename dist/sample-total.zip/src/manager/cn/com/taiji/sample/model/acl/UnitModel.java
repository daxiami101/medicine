package cn.com.taiji.sample.model.acl;

import cn.com.taiji.sample.entity.Unit;

public class UnitModel extends Unit {

	private boolean hasChild;

	public boolean isHasChild() {
		return hasChild;
	}

	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}
	
	
}
