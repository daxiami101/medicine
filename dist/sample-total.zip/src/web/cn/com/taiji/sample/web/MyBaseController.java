/*
 * Date: 2012-6-28
 * author: Peream  (peream@gmail.com)
 *
 */
package cn.com.taiji.sample.web;

import cn.com.taiji.common.web.JsonValidController;

/**
 * 
 * @author Peream <br>
 *         Create Time：2012-6-28 下午6:27:27<br>
 *         <a href="mailto:peream@gmail.com">peream@gmail.com</a>
 * @since 1.0
 * @version 1.0
 */
public abstract class MyBaseController extends JsonValidController
{

}
