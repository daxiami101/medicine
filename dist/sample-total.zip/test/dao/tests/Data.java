package tests;

import cn.com.taiji.common.entity.BaseEntity;

class Data extends BaseEntity
{
	private String code;
	private String name;
	private int list;

	public Data()
	{

	}

	public Data(String code, String name, int list)
	{
		super();
		this.code = code;
		this.name = name;
		this.list = list;
	}

	public String getCode()
	{
		return code;
	}

	public String getName()
	{
		return name;
	}

	public int getList()
	{
		return list;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void setList(int list)
	{
		this.list = list;
	}

}