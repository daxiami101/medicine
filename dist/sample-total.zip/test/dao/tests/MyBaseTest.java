package tests;

import cn.com.taiji.common.pub.ProjectEnv;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-26 下午06:51:20
 * @since 1.0
 * @version 1.0
 */
public abstract class MyBaseTest extends BaseTest
{
	static 
	{
		System.setProperty("webapp.sample", "war");
		ProjectEnv.webappPath = "war";
	}
}
