package tests.cn.com.taiji.sample.manager.acl;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * 
 * @author Peream <br>
 *         邮箱：peream@gmail.com<br>
 *         创建日期：2009-4-28 下午05:12:15
 * @since 1.0
 * @version 1.0
 */
@RunWith(Suite.class)
@SuiteClasses({TestUserManager.class, TestRoleManager.class, TestResourceManager.class, TestAclManager.class, TestRoleResourceManager.class,
		TestUserManager.class })
public class AclSuite
{

}
